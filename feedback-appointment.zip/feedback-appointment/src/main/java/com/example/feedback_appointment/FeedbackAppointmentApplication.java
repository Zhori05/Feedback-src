package com.example.feedback_appointment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeedbackAppointmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeedbackAppointmentApplication.class, args);
	}

}
