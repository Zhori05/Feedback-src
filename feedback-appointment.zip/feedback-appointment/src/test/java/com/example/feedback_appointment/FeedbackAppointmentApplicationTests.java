package com.example.feedback_appointment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeedbackAppointmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
